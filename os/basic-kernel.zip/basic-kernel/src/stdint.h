/*
 * stdint.h - 内核基本整数类型定义
 */
#ifndef _STDINT_H
#define _STDINT_H

typedef signed char         int8_t;
typedef unsigned char       uint8_t;
typedef signed short        int16_t;
typedef unsigned short      uint16_t;
typedef signed int          int32_t;
typedef unsigned int        uint32_t;
typedef signed long long    int64_t;
typedef unsigned long long  uint64_t;

typedef int32_t             intptr_t;
typedef uint32_t            uintptr_t;

#endif /* _STDINT_H */